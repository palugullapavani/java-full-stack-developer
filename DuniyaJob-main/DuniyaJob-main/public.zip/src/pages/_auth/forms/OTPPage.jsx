import React from 'react'

const OTPPage = () => {
  return (
    <div>OTPPage</div>
  )
}

export default OTPPage