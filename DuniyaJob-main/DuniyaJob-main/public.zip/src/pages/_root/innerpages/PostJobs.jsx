import React from 'react'

const PostJobs = () => {
  return (
    <div>PostJobs</div>
  )
}

export default PostJobs