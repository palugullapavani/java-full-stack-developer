import React from 'react'

const JobSearch = () => {
  return (
    <div>JobSearch</div>
  )
}

export default JobSearch