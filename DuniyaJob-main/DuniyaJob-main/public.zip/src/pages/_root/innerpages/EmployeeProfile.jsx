import React from 'react'

const EmployeeProfile = () => {
  return (
    <div>EmployeeProfile</div>
  )
}

export default EmployeeProfile