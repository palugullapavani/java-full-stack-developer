package com.springboot.springjdbc1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springjdbc1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
